import dlt
from pyspark.sql.functions import *


# create view for transformation
@dlt.view(
    name = 'sales_enr_view'
)
def sales_enr_view():
    df = spark.readStream.table("demo_pipline.dlt_demo.sales_stg")
    df = df.withColumn("total_amount", col('price') * col('quantity'))
    return df

# create destination streaming table for sales
dlt.create_streaming_table(
    name = "sales_enr"
)

# create auto-cdc flow
dlt.create_auto_cdc_flow(
    target = "sales_enr",
    source = "sales_enr_view",
    keys = ["sale_id"],
    sequence_by = "sale_date",
    ignore_null_updates = False,
    apply_as_deletes = None,
    apply_as_truncates = None,
    column_list = None,
    except_column_list = None,
    stored_as_scd_type = 1,
    track_history_column_list = None,
    track_history_except_column_list = None
)

import dlt
from pyspark.sql.functions import *

# ceate Materialized table
@dlt.table(
    name = "business_customer_purchase"
)
def business_customer_purchase():
    df_cust = spark.read.table("dim_customers")
    df_prod = spark.read.table("dim_products")
    df_sales = spark.read.table("fact_sales")

    df_join = df_sales.join(df_cust, df_sales.customer_id == df_cust.customer_id, "inner")
    df_join = df_join.join(df_prod, df_sales.product_id == df_prod.product_id, "inner")
    df_join = df_join.select("fact_sales.customer_id", "dim_customers.customer_name", "fact_sales.total_amount")
    df_agg = df_join.groupBy("customer_id", "customer_name").agg(sum("total_amount").alias("total_purchase"))
    return df_agg


import dlt
from pyspark.sql.functions import *

# create expectations for customers
product_rules = {
    "rule_1" : "product_id IS NOT NULL",
    "rule_2" : lower(col("available")).isin("true", "false")
}
 # ingest products
@dlt.table(
    name = "products_stg"
 )
@dlt.expect_all_or_drop(product_rules)
def products_stg():
     df = spark.readStream.table("demo_pipline.pipeline_schema.products")
     return df
 
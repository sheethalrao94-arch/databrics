import dlt

# create expectation
sales_rules = {
    "rule_1" : "quantity > 0"
}

# create empty streaming table
dlt.create_streaming_table(
    name = "sales_stg",
    expect_all_or_drop = sales_rules
)

# create flow for 'sales_south'
@dlt.append_flow(target='sales_stg')
def load_sales_south():
    df = spark.readStream.table("demo_pipline.pipeline_schema.sales_south")
    return df

# create flow for 'sales_north'
@dlt.append_flow(target='sales_stg')
def load_sales_north():
    df = spark.readStream.table("demo_pipline.pipeline_schema.sales_north")
    return df

import dlt
# create customers expectation
customers_rules = {
    "rule_1" : "customer_id IS NOT NULL",
    "rule_2" : "email IS NOT NULL",
    "rule_3" : "email LIKE '%@%'",
    "rule_4" : "email LIKE '%.%'"
}

# ingest customers
@dlt.table(
    name = "customers_stg"
)
@dlt.expect_all_or_drop(customers_rules)
def customers_stg():
    df = spark.readStream.table("demo_pipline.pipeline_schema.customers");
    return df

import dlt
from pyspark.sql.functions import *


# create view for transformation
@dlt.view(
    name = 'products_enr_view'
)
def products_enr_view():
    df = spark.readStream.table("demo_pipline.dlt_demo.products_stg")
    df = df.withColumn("percentage_discount", lit("10"))
    return df

# create destination streaming table for products
dlt.create_streaming_table(
    name = "products_enr"
)

# create auto-cdc flow
dlt.create_auto_cdc_flow(
    target = "products_enr",
    source = "products_enr_view",
    keys = ["product_id"],
    sequence_by = "last_updated",
    ignore_null_updates = False,
    apply_as_deletes = None,
    apply_as_truncates = None,
    column_list = None,
    except_column_list = None,
    stored_as_scd_type = 1,
    track_history_column_list = None,
    track_history_except_column_list = None
)
